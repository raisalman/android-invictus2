package net.invictusmanagement.invictuslifestyle;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Debug;
import android.preference.PreferenceManager;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import java.util.UUID;

public class LoginActivity extends BaseActivity {

    private EditText _emailView;
    private EditText _activationCodeView;
    private View _progressView;
    private Button _activateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        _emailView = (EditText) findViewById(R.id.email);
        _activationCodeView = (EditText) findViewById(R.id.activationCode);
        _progressView = findViewById(R.id.activation_progress);

        _activateButton = (Button) findViewById(R.id.activate_button);
        _activateButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });

        _activateButton.setEnabled(Utilities.checkPlayServices(this));

        if (Debug.isDebuggerConnected()) {
            _emailView.setText("hblakeslee@gmail.com");
            _activationCodeView.setText("31d3f1a6-95f0-4d9c-b120-0933ee6c1fb2");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_about:
                Utilities.showAboutDialog(this);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    private void attemptLogin() {

        _emailView.setError(null);
        _activationCodeView.setError(null);

        String email = _emailView.getText().toString();
        String activationCode = _activationCodeView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(email)) {
            _emailView.setError(getString(R.string.error_field_required));
            focusView = _emailView;
            cancel = true;
        } else if (!Utilities.isValidEmail(_emailView.getText())) {
            _emailView.setError(getString(R.string.error_invalid_email));
            focusView = _emailView;
            cancel = true;
        } else if (TextUtils.isEmpty(activationCode)) {
            _activationCodeView.setError(getString(R.string.error_field_required));
            focusView = _activationCodeView;
            cancel = true;

        } else if (!isActivationCodeValid(activationCode)) {
            _activationCodeView.setError(getString(R.string.error_invalid_activationCode));
            focusView = _activationCodeView;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {

            new AsyncTask<String, Void, AuthenticationResult>() {

                private String _activationCode;

                @Override
                protected void onPreExecute() {

                    Utilities.hideKeyboard(LoginActivity.this);
                    showProgress(true);
                }

                @Override
                protected AuthenticationResult doInBackground(String... args) {
                    _activationCode = args[1];
                    try {
                        return MobileDataProvider.getInstance().authenticate(args[0], _activationCode);
                    } catch (Exception ex) {
                        Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                        return null;
                    }
                }

                @Override
                protected void onPostExecute(AuthenticationResult result) {
                    if (result != null && !TextUtils.isEmpty(result.authenticationCookie)) {
                        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                        sharedPreferences.edit().putString("activationCode", _activationCode).apply();
                        sharedPreferences.edit().putLong("userId", result.userId).apply();
                        sharedPreferences.edit().putString("authenticationCookie", result.authenticationCookie).apply();
                        MobileDataProvider.getInstance().setAuthenticationCookie(result.authenticationCookie);
                        Intent intent = new Intent(LoginActivity.this, TabbedActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    } else {
                        showProgress(false);
                        _emailView.setError(getString(R.string.error_invalid_login));
                        _emailView.requestFocus();
                    }
                }
            }.execute(email, activationCode);
        }
    }

    private boolean isActivationCodeValid(String activationCode) {
        try {
            UUID id = UUID.fromString(activationCode);
        } catch (IllegalArgumentException ex) {
            return false;
        }
        return true;
    }

    private void showProgress(final boolean show) {
        Utilities.showHide(this, _activateButton, !show);
        Utilities.showHide(this, _progressView, show);
    }
}

