package net.invictusmanagement.invictuslifestyle;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class HomeFragment extends Fragment implements IRefreshableFragment {

    private SwipeRefreshLayout _swipeRefreshLayout;
    private Context _context;
    private TextView _welcomeTextView;
    private MediaPlayer _mediaPlayer;

    public HomeFragment() {
    }

    @SuppressWarnings("unused")
    public static HomeFragment newInstance() {

        return new HomeFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        _mediaPlayer = MediaPlayer.create(_context, R.raw.intro);
        _mediaPlayer.setLooping(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);
        if (view instanceof SwipeRefreshLayout) {

            _swipeRefreshLayout = (SwipeRefreshLayout) view;
            _swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(_context, R.color.colorPrimary));
            _swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    refresh();
                }
            });
            _welcomeTextView = (TextView) view.findViewById(R.id.welcome);

            final SurfaceView surfaceView = (SurfaceView) view.findViewById(R.id.media);
            surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
                @Override
                public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                }

                @Override
                public void surfaceCreated(SurfaceHolder holder) {
                    _mediaPlayer.setDisplay(holder);
                    _mediaPlayer.start();
                }

                @Override
                public void surfaceDestroyed(SurfaceHolder holder) {
                }
            });

            ((Button) view.findViewById(R.id.button_access_points)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TabbedActivity) _context).setSelectedTab(TabbedActivity.FRAGMENT_POSITION_ACCESS_POINTS);
                }
            });
            ((Button) view.findViewById(R.id.button_coupons)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TabbedActivity) _context).setSelectedTab(TabbedActivity.FRAGMENT_POSITION_PROMOTIONS);
                }
            });
            ((Button) view.findViewById(R.id.button_digital_key)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TabbedActivity) _context).setSelectedTab(TabbedActivity.FRAGMENT_POSITION_DIGITAL_KEYS);
                }
            });
            ((Button) view.findViewById(R.id.button_notifications)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TabbedActivity) _context).setSelectedTab(TabbedActivity.FRAGMENT_POSITION_NOTIFICATIONS);
                }
            });
            ((Button) view.findViewById(R.id.button_maintenance_reqs)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TabbedActivity) _context).setSelectedTab(TabbedActivity.FRAGMENT_POSITION_MAINTENANCE_REQUESTS);
                }
            });
            ((Button) view.findViewById(R.id.button_health)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TabbedActivity) _context).setSelectedTab(TabbedActivity.FRAGMENT_POSITION_HEALTH);
                }
            });
            ((Button) view.findViewById(R.id.button_insurance)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TabbedActivity) _context).setSelectedTab(TabbedActivity.FRAGMENT_POSITION_INSURANCE);
                }
            });
            refresh();
        }
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        _context = context;
    }

    @Override
    public void onDestroy() {
        if (_mediaPlayer != null) {
            if (_mediaPlayer.isPlaying())
                _mediaPlayer.stop();
            _mediaPlayer.reset();
            _mediaPlayer.release();
            _mediaPlayer = null;
        }
        super.onDestroy();
    }

    public void refresh() {
        if (_swipeRefreshLayout == null)
            return;

        new AsyncTask<Void, Void, User>() {

            @Override
            protected void onPreExecute() {
                _swipeRefreshLayout.setRefreshing(true);
            }

            @Override
            protected User doInBackground(Void... args) {
                try {
                    return MobileDataProvider.getInstance().getUser();
                } catch (Exception ex) {
                    Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                    return null;
                }
            }

            @Override
            protected void onPostExecute(User user) {
                _swipeRefreshLayout.setRefreshing(false);
                if (user != null)
                    _welcomeTextView.setText("Welcome " + user.displayName + "!");
                else
                    Toast.makeText(getActivity(), "Unable to refresh current user. Please try again later.", Toast.LENGTH_LONG).show();
            }
        }.execute();
    }
}
