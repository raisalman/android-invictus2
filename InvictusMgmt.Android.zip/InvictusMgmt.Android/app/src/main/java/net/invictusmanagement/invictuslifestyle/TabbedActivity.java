package net.invictusmanagement.invictuslifestyle;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Debug;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.microsoft.windowsazure.notifications.NotificationsManager;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TabbedActivity extends BaseActivity implements AccessPointsListFragmentInteractionListener,
        BusinessTypesListFragmentInteractionListener,
        NotificationsListFragmentInteractionListener,
        MaintenanceRequestsListFragmentInteractionListener,
        DigitalKeysListFragmentInteractionListener {


    public static final int FRAGMENT_POSITION_HOME = 0;
    public static final int FRAGMENT_POSITION_ACCESS_POINTS = 1;
    public static final int FRAGMENT_POSITION_PROMOTIONS = 2;
    public static final int FRAGMENT_POSITION_DIGITAL_KEYS = 3;
    public static final int FRAGMENT_POSITION_NOTIFICATIONS = 4;
    public static final int FRAGMENT_POSITION_MAINTENANCE_REQUESTS = 5;
    public static final int FRAGMENT_POSITION_HEALTH = 6;
    public static final int FRAGMENT_POSITION_INSURANCE = 7;

    private int _currentTabPosition = 0;
    private SectionsPagerAdapter _sectionsPagerAdapter;
    private TabLayout _tabLayout;
    private ViewPager _viewPager;
    private FloatingActionButton _newFloatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_tabbed);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        _sectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        _viewPager = (ViewPager) findViewById(R.id.container);
        _viewPager.setAdapter(_sectionsPagerAdapter);

        _tabLayout = (TabLayout) findViewById(R.id.tabs);
        _tabLayout.setupWithViewPager(_viewPager);
        _tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                _currentTabPosition = tab.getPosition();
                _viewPager.setCurrentItem(_currentTabPosition);
                Utilities.showHide(TabbedActivity.this, _newFloatingActionButton, _currentTabPosition == FRAGMENT_POSITION_DIGITAL_KEYS || _currentTabPosition == FRAGMENT_POSITION_MAINTENANCE_REQUESTS);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        _newFloatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        _newFloatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_viewPager.getCurrentItem() == FRAGMENT_POSITION_DIGITAL_KEYS) {
                    startActivityForResult(new Intent(TabbedActivity.this, NewDigitalKeyActivity.class), FRAGMENT_POSITION_DIGITAL_KEYS);
                } else if (_viewPager.getCurrentItem() == FRAGMENT_POSITION_MAINTENANCE_REQUESTS) {
                    startActivityForResult(new Intent(TabbedActivity.this, NewMaintenanceRequestActivity.class), FRAGMENT_POSITION_MAINTENANCE_REQUESTS);
                }
            }
        });

        MobileDataProvider.getInstance().setOnForbiddenListener(new MobileDataProvider.onForbiddenListener() {
            @Override
            public void forbidden() {
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(TabbedActivity.this);
                sharedPreferences.edit().remove("activationCode").apply();
                sharedPreferences.edit().remove("authenticationCookie").apply();
                MobileDataProvider.getInstance().setAuthenticationCookie(null);
            }
        });

        if (Utilities.checkPlayServices(this)) {
            if (Debug.isDebuggerConnected()) {
                // Not sure why this delay is needed during debugging.
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        NotificationsManager.handleNotifications(TabbedActivity.this, NotificationSettings.SenderId, ChatNotificationHandler.class);
                        startService(new Intent(TabbedActivity.this, ChatRegistrationIntentService.class));
                    }
                }, 100);
            } else {
                NotificationsManager.handleNotifications(TabbedActivity.this, NotificationSettings.SenderId, ChatNotificationHandler.class);
                startService(new Intent(TabbedActivity.this, ChatRegistrationIntentService.class));
            }
        }   // Google play services available?
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_tabbed, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                startActivity(new Intent(TabbedActivity.this, SettingsActivity.class));
                return true;

            case R.id.action_feedback:
                startActivity(new Intent(TabbedActivity.this, NewFeedbackActivity.class));
                return true;

            case R.id.action_refresh:
                ((IRefreshableFragment) getSupportFragmentManager().findFragmentByTag("android:switcher:" + _viewPager.getId() + ":" + _currentTabPosition)).refresh();
                return true;

            case R.id.action_about:
                Utilities.showAboutDialog(this);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onListFragmentInteraction(final AccessPoint item) {

        AlertDialog.Builder builder = new AlertDialog.Builder(TabbedActivity.this);
        builder.setMessage("Are you sure you want to open the " + item.name + " access point?")
                .setTitle("Open Access Point");
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                new AsyncTask<AccessPoint, Void, Boolean>() {

                    @Override
                    protected Boolean doInBackground(AccessPoint... params) {
                        try {
                            OpenAccessPoint model = new OpenAccessPoint();
                            model.id = params[0].id;
                            model.isSilent = true;
                            MobileDataProvider.getInstance().openAccessPoint(model);
                            return true;
                        } catch (Exception ex) {
                            Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                            return false;
                        }
                    }

                    @Override
                    protected void onPostExecute(Boolean success) {
                        if (success)
                            Toast.makeText(TabbedActivity.this, item.name + " was successfully opened.", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(TabbedActivity.this, "Opening the " + item.name + " access point failed.  Please try again later.", Toast.LENGTH_LONG).show();
                    }
                }.execute(item);
            }
        });
        builder.create().show();
    }

    @Override
    public void onListFragmentInteraction(final BusinessType item) {
        Intent intent = new Intent(this, BusinessesActivity.class);
        intent.putExtra(BusinessesActivity.EXTRA_BUSINESS_TYPE_JSON, new Gson().toJson(item));
        startActivity(intent);
    }

    @Override
    public void onListFragmentInteraction(final Notification item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(TabbedActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_notification, null);
        builder.setView(view)
                .setTitle(item.title);

        DateFormat formatter = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT);
        ((TextView) view.findViewById(R.id.createdUtc)).setText(formatter.format(item.createdUtc));
        ((TextView) view.findViewById(R.id.message)).setText(item.message);

        builder.setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.create().show();
    }

    @Override
    public void onListFragmentInteraction(final MaintenanceRequest item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(TabbedActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_maintenance_request, null);
        builder.setView(view)
                .setTitle(item.title);

        DateFormat formatter = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT);
        ((TextView) view.findViewById(R.id.createdUtc)).setText(formatter.format(item.createdUtc));
        ((TextView) view.findViewById(R.id.status)).setText(item.status.toString());
        ((TextView) view.findViewById(R.id.description)).setText(item.description);

        view.findViewById(R.id.closedUtcLabel).setVisibility(item.status == MaintenanceRequest.Status.Closed ? View.VISIBLE : View.GONE);
        view.findViewById(R.id.closedUtc).setVisibility(item.status == MaintenanceRequest.Status.Closed ? View.VISIBLE : View.GONE);
        if (item.status == MaintenanceRequest.Status.Closed)
            ((TextView) view.findViewById(R.id.closedUtc)).setText(formatter.format(item.closedUtc));

        builder.setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.create().show();
    }

    @Override
    public void onListFragmentInteraction(final DigitalKey item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(TabbedActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_digital_key, null);

        builder.setView(view)
                .setTitle(item.recipient);

        String status = "Expired";
        if (item.isRevoked)
            status = "Revoked";
        else {
            Date now = new Date();
            if (now.after(item.fromUtc) && now.before(item.toUtc))
                status = "Valid";
            else if (now.before(item.fromUtc) && now.before(item.toUtc))
                status = "Upcoming";
        }
        ((TextView) view.findViewById(R.id.status)).setText(status);
        DateFormat formatter = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT);
        ((TextView) view.findViewById(R.id.createdUtc)).setText(formatter.format(item.createdUtc));
        ((TextView) view.findViewById(R.id.fromUtc)).setText(formatter.format(item.fromUtc));
        ((TextView) view.findViewById(R.id.toUtc)).setText(formatter.format(item.toUtc));
        view.findViewById(R.id.notes_label).setVisibility(TextUtils.isEmpty(item.notes) ? View.GONE : View.VISIBLE);
        ((TextView) view.findViewById(R.id.notes)).setText(item.notes);

        builder.setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        if (!item.isRevoked && !status.equals("Expired")) {
            builder.setNegativeButton("Revoke", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(TabbedActivity.this);
                    builder.setMessage("Are you sure you want to revoke " + item.recipient + " digital key?")
                            .setTitle("Revoke Digital Key");
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            new AsyncTask<DigitalKey, Void, Boolean>() {

                                @Override
                                protected Boolean doInBackground(DigitalKey... params) {
                                    try {
                                        DigitalKeyUpdate model = new DigitalKeyUpdate();
                                        model.id = params[0].id;
                                        model.isRevoked = true;
                                        MobileDataProvider.getInstance().updateDigitalKey(model);
                                        params[0].isRevoked = true;
                                        return true;
                                    } catch (Exception ex) {
                                        Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                                        return false;
                                    }
                                }

                                @Override
                                protected void onPostExecute(Boolean success) {
                                    if (success)
                                        Toast.makeText(TabbedActivity.this, item.recipient + " digital key was successfully revoked.", Toast.LENGTH_LONG).show();
                                    else
                                        Toast.makeText(TabbedActivity.this, item.recipient + " digital key failed to be revoked.  Please try again later.", Toast.LENGTH_LONG).show();
                                }
                            }.execute(item);
                        }
                    });
                    builder.create().show();
                }
            });
        }
        builder.create().show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if ((requestCode == FRAGMENT_POSITION_DIGITAL_KEYS || requestCode == FRAGMENT_POSITION_MAINTENANCE_REQUESTS) && resultCode > 0) {
            ((IRefreshableFragment) getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.container + ":" + _viewPager.getCurrentItem())).refresh();
        }
    }

    public void setSelectedTab(int index) {
        _tabLayout.getTabAt(index).select();
    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {

            Fragment fragment = null;
            switch (position) {
                case FRAGMENT_POSITION_HOME:
                    fragment = HomeFragment.newInstance();
                    break;
                case FRAGMENT_POSITION_ACCESS_POINTS:
                    fragment = AccessPointsFragment.newInstance();
                    break;
                case FRAGMENT_POSITION_PROMOTIONS:
                    fragment = BusinessTypesFragment.newInstance();
                    break;
                case FRAGMENT_POSITION_DIGITAL_KEYS:
                    fragment = DigitalKeysFragment.newInstance();
                    break;
                case FRAGMENT_POSITION_NOTIFICATIONS:
                    fragment = NotificationsFragment.newInstance();
                    break;
                case FRAGMENT_POSITION_MAINTENANCE_REQUESTS:
                    fragment = MaintenanceRequestsFragment.newInstance();
                    break;
                case FRAGMENT_POSITION_HEALTH:
                    fragment = HealthFragment.newInstance();
                    break;
                case FRAGMENT_POSITION_INSURANCE:
                    fragment = InsuranceFragment.newInstance();
                    break;
            }
            return fragment;
        }

        @Override
        public int getCount() {
            return 8;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case FRAGMENT_POSITION_HOME:
                    return "Home";
                case FRAGMENT_POSITION_ACCESS_POINTS:
                    return "Access Points";
                case FRAGMENT_POSITION_PROMOTIONS:
                    return "Coupons";
                case FRAGMENT_POSITION_DIGITAL_KEYS:
                    return "Digital Key";
                case FRAGMENT_POSITION_NOTIFICATIONS:
                    return "Notifications";
                case FRAGMENT_POSITION_MAINTENANCE_REQUESTS:
                    return "Maint Requests";
                case FRAGMENT_POSITION_HEALTH:
                    return "Health & Wellness";
                case FRAGMENT_POSITION_INSURANCE:
                    return "Insurance";
            }
            return null;
        }
    }
}
