package net.invictusmanagement.invictuslifestyle;

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.microsoft.windowsazure.messaging.NotificationHub;

public class ChatRegistrationIntentService extends IntentService {

    public ChatRegistrationIntentService() {
        super(Utilities.TAG);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        try {

            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String activationCode = sharedPreferences.getString("activationCode", null);
            if (TextUtils.isEmpty(activationCode)) {
                Log.w(Utilities.TAG, "Attempt to register app with Azure notification hub without activation code");
                return;
            }

            String firebaseToken = FirebaseInstanceId.getInstance().getToken();
            Log.d(Utilities.TAG, "Firebase token: " + firebaseToken);

            if (!sharedPreferences.getString("firebaseToken", "").equals(firebaseToken)) {

                NotificationHub hub = new NotificationHub(NotificationSettings.HubName, NotificationSettings.HubListenConnectionString, this);
                Log.d(Utilities.TAG, "Notification Hubs Registration refreshing with firebase token: " + firebaseToken);

                String template = "{ \"data\": { \"id\": \"$(id)\", \"caller\": \"$(caller)\", \"room\": \"$(room)\", \"accessPointName\": \"$(accessPointName)\", \"validUntilDateUtc\": \"$(validUntilDateUtc)\" } }";
                String registrationId = hub.registerTemplate(firebaseToken, "VideoChatTemplate", template, activationCode).getRegistrationId();
                Log.d(Utilities.TAG, "New Notification Hubs Registration Successful: " + registrationId);

                sharedPreferences.edit().putString("firebaseToken", firebaseToken).apply();
            }

        } catch (Exception ex) {
            Log.e(Utilities.TAG, "Failed to complete push notification registration", ex);
        }
    }
}
