package net.invictusmanagement.invictuslifestyle;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.microsoft.windowsazure.notifications.NotificationsManager;
import com.twilio.video.AudioTrack;
import com.twilio.video.CameraCapturer;
import com.twilio.video.ConnectOptions;
import com.twilio.video.LocalAudioTrack;
import com.twilio.video.LocalParticipant;
import com.twilio.video.LocalVideoTrack;
import com.twilio.video.Participant;
import com.twilio.video.Room;
import com.twilio.video.RoomState;
import com.twilio.video.TwilioException;
import com.twilio.video.Video;
import com.twilio.video.VideoTrack;
import com.twilio.video.VideoView;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ChatActivity extends BaseActivity {

    public final static String EXTRA_ACCESS_POINT_ID = "net.invictusmanagement.invictusmobile.Access.Point.Id";
    public final static String EXTRA_CALLER_NAME = "net.invictusmanagement.invictusmobile.Caller.Name";
    public final static String EXTRA_ACCESSPOINT_NAME = "net.invictusmanagement.invictusmobile.AccessPoint.Name";
    public final static String EXTRA_ROOM_ID = "net.invictusmanagement.invictusmobile.Room.Id";

    private static final int CAMERA_MIC_PERMISSION_REQUEST_CODE = 1;

    private ProgressBar _progressBar;
    private VideoView _remoteVideoView;
    private VideoView _localVideoView;
    private FloatingActionButton _buttonAnswer;
    private FloatingActionButton _buttonOpenAccessPoint;
    private FloatingActionButton _buttonVideoMail;

    private Boolean _isDoNotDisturb;
    private CameraCapturer _cameraCapturer;
    private LocalAudioTrack _localAudioTrack;
    private LocalVideoTrack _localVideoTrack;

    private int _accessPointId;
    private Room _room;
    private String _kioskName;
    private String _accessPointName;
    private String _roomId;

    private Ringtone _ringtone;
    private int _previousAudioMode;
    private boolean _previousIsSpeakerPhoneOn;
    private boolean _previousMicrophoneMute;
    private int _previousRingerMode;
    private AudioManager _audioManager;
    private boolean _hasCameraAndMicPermissions;
    private Timer _timer;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_chat);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);

        _progressBar = (ProgressBar) findViewById(R.id.progress);
        _localVideoView = (VideoView) findViewById(R.id.video_local);
        _remoteVideoView = (VideoView) findViewById(R.id.video_remote);
        _buttonAnswer = (FloatingActionButton) findViewById(R.id.button_answer);
        _buttonOpenAccessPoint = (FloatingActionButton) findViewById(R.id.button_open_access_point);
        _buttonVideoMail = (FloatingActionButton) findViewById(R.id.button_video_mail);

        _buttonAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_ringtone != null)
                    _ringtone.stop();

                if (_room == null || _room.getState() != RoomState.CONNECTED || !_hasCameraAndMicPermissions)
                    return;

                Utilities.showHide(ChatActivity.this, _buttonAnswer, false);
                Utilities.showHide(ChatActivity.this, _buttonVideoMail, false);

                _localAudioTrack = LocalAudioTrack.create(ChatActivity.this, true);
                _cameraCapturer = new CameraCapturer(ChatActivity.this, CameraCapturer.CameraSource.FRONT_CAMERA);
                _localVideoTrack = LocalVideoTrack.create(ChatActivity.this, true, _cameraCapturer);
                _localVideoTrack.addRenderer(_localVideoView);
                LocalParticipant participant = _room.getLocalParticipant();
                participant.addAudioTrack(_localAudioTrack);
                participant.addVideoTrack(_localVideoTrack);
                setAutoFinishTimer();
            }
        });

        _buttonOpenAccessPoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new AsyncTask<Void, Void, Boolean>() {

                    @Override
                    protected void onPreExecute() {
                        if (_ringtone != null)
                            _ringtone.stop();
                    }

                    @Override
                    protected Boolean doInBackground(Void... args) {
                        try {
                            OpenAccessPoint model = new OpenAccessPoint();
                            model.id = _accessPointId;
                            model.isSilent = false;
                            MobileDataProvider.getInstance().openAccessPoint(model);
                            return true;
                        } catch (Exception ex) {
                            Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                            return false;
                        }
                    }

                    @Override
                    protected void onPostExecute(Boolean success) {
                        Toast.makeText(ChatActivity.this, success ? _accessPointName + " was successfully opened." :
                                "Opening the " + _accessPointName + " access point failed.", Toast.LENGTH_LONG).show();
                        finish();
                    }
                }.execute();
            }
        });

        _buttonVideoMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new AsyncTask<Void, Void, Boolean>() {

                    @Override
                    protected void onPreExecute() {
                        if (_ringtone != null)
                            _ringtone.stop();
                    }

                    @Override
                    protected Boolean doInBackground(Void... args) {
                        try {
                            MobileDataProvider.getInstance().sendToVoiceMail(_accessPointId);
                            return true;
                        } catch (Exception ex) {
                            Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                            return false;
                        }
                    }

                    @Override
                    protected void onPostExecute(Boolean success) {
                        finish();
                    }
                }.execute();
            }
        });

        final Intent intent = getIntent();
        _accessPointId = Integer.parseInt(intent.getStringExtra(EXTRA_ACCESS_POINT_ID));
        _kioskName = intent.getStringExtra(EXTRA_CALLER_NAME);
        // If this isn't a new app install the push notification template will already have be registered without the accessPointName so let's default
        // the access point name to the kiosk name.
        _accessPointName = TextUtils.isEmpty(intent.getStringExtra(EXTRA_ACCESSPOINT_NAME)) ? _kioskName : intent.getStringExtra(EXTRA_ACCESSPOINT_NAME);
        _roomId = intent.getStringExtra(EXTRA_ROOM_ID);

        setTitle("Call from " + _kioskName);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        MobileDataProvider.getInstance().setAuthenticationCookie(sharedPreferences.getString("authenticationCookie", null));

        _hasCameraAndMicPermissions = checkPermissionForCameraAndMicrophone();
        if (!_hasCameraAndMicPermissions)
            requestPermissionForCameraAndMicrophone();

        try {

            _isDoNotDisturb = false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                _isDoNotDisturb = notificationManager.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_NONE;
            }
            setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
            _audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

            _previousAudioMode = _audioManager.getMode();
            _audioManager.requestAudioFocus(null, AudioManager.STREAM_VOICE_CALL, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            _audioManager.setMode(AudioManager.MODE_IN_CALL);

            _previousRingerMode = _audioManager.getRingerMode();
            if (!_isDoNotDisturb)
                _audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);

            _previousIsSpeakerPhoneOn = _audioManager.isSpeakerphoneOn();
            _audioManager.setSpeakerphoneOn(true);

            _previousMicrophoneMute = _audioManager.isMicrophoneMute();
            _audioManager.setMicrophoneMute(false);

            final Uri uri = Uri.parse(sharedPreferences.getString("chat_ringtone", RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE).toString()));
            _ringtone = RingtoneManager.getRingtone(this, uri);

            new AsyncTask<String, Void, ChatToken>() {

                private String _roomId;

                @Override
                protected void onPreExecute() {
                    if (_ringtone != null)
                        _ringtone.play();
                }

                @Override
                protected ChatToken doInBackground(String... args) {
                    try {
                        _roomId = args[0];
                        return MobileDataProvider.getInstance().getChatToken(_roomId);
                    } catch (Exception ex) {
                        Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                        return null;
                    }
                }

                @Override
                protected void onPostExecute(ChatToken token) {

                    if (token == null) {
                        Toast.makeText(ChatActivity.this, "Unable to initialize video chat.  Please try again later.", Toast.LENGTH_LONG).show();
                    } else {
                        try {
                            ConnectOptions connectOptions = new ConnectOptions.Builder(token.token)
                                    .roomName(_roomId)
                                    .build();
                            _room = Video.connect(ChatActivity.this, connectOptions, roomListener());
                            Log.d(Utilities.TAG, "Connecting to room: " + _room.getName());
                            setAutoFinishTimer();

                        } catch (Exception ex) {
                            Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                            Toast.makeText(ChatActivity.this, "Unable to connect to the specified video chat room.  Please try again later.", Toast.LENGTH_LONG).show();
                        }
                    }
                }

            }.execute(_roomId);

        } catch (Exception ex) {
            Log.e(Utilities.TAG, Log.getStackTraceString(ex));
            Toast.makeText(this, "Unable to initialize video chat.  Please try again later.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_MIC_PERMISSION_REQUEST_CODE) {

            _hasCameraAndMicPermissions = true;
            for (int grantResult : grantResults) {
                _hasCameraAndMicPermissions &= grantResult == PackageManager.PERMISSION_GRANTED;
            }

            if (!_hasCameraAndMicPermissions)
                notifyPermissionsNeeded();

            Utilities.showHide(ChatActivity.this, _buttonAnswer, _hasCameraAndMicPermissions);
        }
    }

    @Override
    protected void onDestroy() {

        if (_timer != null) {
            Log.d(Utilities.TAG, "Stopping auto finish timer.");
            _timer.cancel();
            _timer.purge();
        }

        if (_ringtone != null && _ringtone.isPlaying())
            _ringtone.stop();

        if (_audioManager != null) {
            _audioManager.setMode(_previousAudioMode);
            _audioManager.abandonAudioFocus(null);
            _audioManager.setSpeakerphoneOn(_previousIsSpeakerPhoneOn);
            _audioManager.setMicrophoneMute(_previousMicrophoneMute);
            if (!_isDoNotDisturb)
                _audioManager.setRingerMode(_previousRingerMode);
        }

        if (_room != null && _room.getState() != RoomState.DISCONNECTED) {
            Log.d(Utilities.TAG, "Disconnecting from room.");
            _room.disconnect();
        }

        if (_localAudioTrack != null) {
            Log.d(Utilities.TAG, "Releasing local audio.");
            _localAudioTrack.release();
            _localAudioTrack = null;
        }

        if (_localVideoTrack != null) {
            Log.d(Utilities.TAG, "Releasing local video.");
            _localVideoTrack.release();
            _localVideoTrack = null;
        }
        super.onDestroy();
    }

    private Room.Listener roomListener() {
        return new Room.Listener() {
            @Override
            public void onConnected(Room room) {
                Log.d(Utilities.TAG, "Connected to room: " + room.getName());
                Utilities.showHide(ChatActivity.this, _buttonAnswer, _hasCameraAndMicPermissions);
                List<Participant> participants = room.getParticipants();
                if (!participants.isEmpty()) {
                    Participant participant = participants.iterator().next();
                    if (participant.getVideoTracks().size() > 0) {
                        Log.d(Utilities.TAG, "Adding participant video (onConnected): " + participant.getIdentity());
                        VideoTrack track = participant.getVideoTracks().get(0);
                        track.addRenderer(_remoteVideoView);
                    }
                    participant.setListener(participantListener());
                }
                Utilities.showHide(ChatActivity.this, _progressBar, false);
            }

            @Override
            public void onConnectFailure(Room room, TwilioException e) {
                Log.e(Utilities.TAG, e.getMessage());
                Toast.makeText(ChatActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onDisconnected(Room room, TwilioException e) {
                Log.d(Utilities.TAG, "Disconnected from room: " + room.getName());
                ChatActivity.this._room = null;
            }

            @Override
            public void onParticipantConnected(Room room, Participant participant) {
                Log.d(Utilities.TAG, "Participant connected: " + participant.getIdentity());
                if (participant.getVideoTracks().size() > 0) {
                    Log.d(Utilities.TAG, "Adding participant video (onParticipantConnected): " + participant.getIdentity());
                    VideoTrack track = participant.getVideoTracks().get(0);
                    track.addRenderer(_remoteVideoView);
                }
                participant.setListener(participantListener());
            }

            @Override
            public void onParticipantDisconnected(Room room, Participant participant) {
                if (participant != null) {
                    Log.d(Utilities.TAG, "Participant disconnected: " + participant.getIdentity());
                    if (participant.getVideoTracks().size() > 0) {
                        Log.d(Utilities.TAG, "Removing participant video: " + participant.getIdentity());
                        VideoTrack track = participant.getVideoTracks().get(0);
                        track.removeRenderer(_remoteVideoView);
                    }
                }   // participant null?
                finish();
            }

            @Override
            public void onRecordingStarted(Room room) {
            }

            @Override
            public void onRecordingStopped(Room room) {
            }
        };
    }

    private Participant.Listener participantListener() {
        return new Participant.Listener() {

            @Override
            public void onAudioTrackAdded(Participant participant, AudioTrack audioTrack) {
            }

            @Override
            public void onAudioTrackRemoved(Participant participant, AudioTrack audioTrack) {
            }

            @Override
            public void onVideoTrackAdded(Participant participant, VideoTrack videoTrack) {
                Log.d(Utilities.TAG, "Adding video track.");
                videoTrack.addRenderer(_remoteVideoView);
            }

            @Override
            public void onVideoTrackRemoved(Participant participant, VideoTrack videoTrack) {
                Log.d(Utilities.TAG, "Removing video track.");
                videoTrack.removeRenderer(_remoteVideoView);
            }

            @Override
            public void onAudioTrackEnabled(Participant participant, AudioTrack audioTrack) {
            }

            @Override
            public void onAudioTrackDisabled(Participant participant, AudioTrack audioTrack) {
            }

            @Override
            public void onVideoTrackEnabled(Participant participant, VideoTrack videoTrack) {
            }

            @Override
            public void onVideoTrackDisabled(Participant participant, VideoTrack videoTrack) {
            }

        };
    }

    private boolean checkPermissionForCameraAndMicrophone() {
        int resultCamera = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA);
        int resultMic = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO);
        return resultCamera == PackageManager.PERMISSION_GRANTED && resultMic == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissionForCameraAndMicrophone() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.CAMERA) ||
                ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.RECORD_AUDIO)) {
            notifyPermissionsNeeded();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO}, CAMERA_MIC_PERMISSION_REQUEST_CODE);
        }
    }

    private void notifyPermissionsNeeded() {
        Log.w(Utilities.TAG, getResources().getString(R.string.permissions_needed));
        Toast.makeText(this, R.string.permissions_needed, Toast.LENGTH_LONG).show();
    }

    private void setAutoFinishTimer() {

        if (_timer != null) {
            Log.d(Utilities.TAG, "Stopping auto finish timer.");
            _timer.cancel();
            _timer.purge();
            _timer = null;
        }   // timer null?

        Log.d(Utilities.TAG, "Starting auto finish timer.");
        _timer = new Timer();
        _timer.schedule(new TimerTask() {
            @Override
            public void run() {
                finish();
            }
        }, 60000);
    }
}
