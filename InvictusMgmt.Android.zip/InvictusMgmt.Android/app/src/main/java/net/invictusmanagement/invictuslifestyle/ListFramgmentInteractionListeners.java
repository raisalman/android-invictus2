package net.invictusmanagement.invictuslifestyle;

/*
    I guess Java doesn't support having a ListFragmentInteractionListener<T extends ModelBase> interface and allow
    our tabbed activity to implement the same interface with different generic types.
*/

interface BusinessesListFragmentInteractionListener {
    void onListFragmentInteraction(Business item);
}

interface AccessPointsListFragmentInteractionListener {
    void onListFragmentInteraction(AccessPoint item);
}

interface BusinessTypesListFragmentInteractionListener {
    void onListFragmentInteraction(BusinessType item);
}

interface NotificationsListFragmentInteractionListener {
    void onListFragmentInteraction(Notification item);
}

interface MaintenanceRequestsListFragmentInteractionListener {
    void onListFragmentInteraction(MaintenanceRequest item);
}

interface DigitalKeysListFragmentInteractionListener {
    void onListFragmentInteraction(DigitalKey item);
}

interface PromotionsListFragmentInteractionListener {
    void onListFragmentInteraction(Promotion item);
}