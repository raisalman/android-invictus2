package net.invictusmanagement.invictuslifestyle;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import net.hockeyapp.android.CrashManager;
import net.hockeyapp.android.metrics.MetricsManager;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!BuildConfig.DEBUG) {
            MetricsManager.register(getApplication());
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        CrashManager.register(this, Utilities.createCrashManagerListerner(this));
    }
}
