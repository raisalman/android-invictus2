package net.invictusmanagement.invictuslifestyle;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class BusinessesActivity extends BaseActivity implements BusinessesListFragmentInteractionListener {

    public static final String EXTRA_BUSINESS_TYPE_JSON = "net.invictusmanagement.invictusmobile.business.type";

    private BusinessType _businessType;
    private RecyclerView _recyclerView;
    private BusinessesAdapter _adapter;
    private SwipeRefreshLayout _swipeRefreshLayout;
    private TextView _feedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_businesses);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        _businessType = new Gson().fromJson(getIntent().getStringExtra(EXTRA_BUSINESS_TYPE_JSON), new TypeToken<BusinessType>() {
        }.getType());

        if (!TextUtils.isEmpty(_businessType.name))
            setTitle(_businessType.name);

        _feedback = (TextView) findViewById(R.id.feedback);
        _recyclerView = (RecyclerView) findViewById(R.id.list);
        _recyclerView.setHasFixedSize(true);
        _recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
        _adapter = new BusinessesAdapter(this);
        _recyclerView.setAdapter(_adapter);

        _swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh);
        _swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(this, R.color.colorPrimary));
        _swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        });
        refresh();
    }

    public void onListFragmentInteraction(final Business item) {
        Intent intent = new Intent(this, PromotionsActivity.class);
        intent.putExtra(PromotionsActivity.EXTRA_BUSINESS_JSON, new Gson().toJson(item));
        startActivity(intent);
    }

    public void refresh() {
        if (_swipeRefreshLayout == null || _adapter == null)
            return;

        new AsyncTask<Void, Void, Boolean>() {

            @Override
            protected void onPreExecute() {
                _swipeRefreshLayout.setRefreshing(true);
            }

            @Override
            protected Boolean doInBackground(Void... args) {
                try {
                    _adapter.refresh(MobileDataProvider.getInstance().getBusinesses(_businessType));
                    return true;
                } catch (Exception ex) {
                    Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean success) {
                _adapter.notifyDataSetChanged();
                _swipeRefreshLayout.setRefreshing(false);
                Utilities.showHide(BusinessesActivity.this, _feedback, _adapter.getItemCount() <= 0);
                Utilities.showHide(BusinessesActivity.this, _recyclerView, _adapter.getItemCount() > 0);
                if (!success)
                    Toast.makeText(BusinessesActivity.this, "Unable to refresh businesses. Please try again later.", Toast.LENGTH_LONG).show();
            }
        }.execute();
    }
}
