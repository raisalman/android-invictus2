package net.invictusmanagement.invictuslifestyle;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MaintenanceRequestsAdapter extends RecyclerView.Adapter<MaintenanceRequestsAdapter.ViewHolder> {

    private Context _context;
    private final List<MaintenanceRequest> _dataSource = new ArrayList<>();
    private final MaintenanceRequestsListFragmentInteractionListener _listener;

    public MaintenanceRequestsAdapter(Context context, MaintenanceRequestsListFragmentInteractionListener listener) {
        _context = context;
        _listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_maintenance_request, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.item = _dataSource.get(position);

        holder.titleTextView.setText(holder.item.title);
        holder.statusTextView.setText(holder.item.status.toString());
        GradientDrawable drawable = (GradientDrawable) holder.iconBackgroundImageView.getDrawable();
        switch (holder.item.status) {
            case Active:
                holder.statusTextView.setText("Active");
                holder.iconImageView.setImageResource(R.drawable.ic_check_white_24dp);
                drawable.setColor(ContextCompat.getColor(_context, R.color.maintReqActive));
                break;
            case Requested:
                holder.statusTextView.setText("Requested");
                holder.iconImageView.setImageResource(R.drawable.ic_hourglass_empty_white_24dp);
                drawable.setColor(ContextCompat.getColor(_context, R.color.maintReqRequested));
                break;
            case Closed:
                holder.statusTextView.setText("Closed");
                holder.iconImageView.setImageResource(R.drawable.ic_block_white_24dp);
                drawable.setColor(ContextCompat.getColor(_context, R.color.maintReqClosed));
                break;
        }
        DateFormat formatter = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT);
        holder.createdUtcTextView.setText(formatter.format(holder.item.createdUtc));

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != _listener) {
                    _listener.onListFragmentInteraction(holder.item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return _dataSource.size();
    }

    public void refresh(List<MaintenanceRequest> list) {
        if (list == null) return;
        _dataSource.clear();
        _dataSource.addAll(list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View view;
        public final ImageView iconBackgroundImageView;
        public final ImageView iconImageView;
        public final TextView titleTextView;
        public final TextView statusTextView;
        public final TextView createdUtcTextView;
        public MaintenanceRequest item;

        public ViewHolder(View view) {
            super(view);
            this.view = view;
            iconBackgroundImageView = (ImageView) view.findViewById(R.id.icon_background);
            iconImageView = (ImageView) view.findViewById(R.id.icon);
            titleTextView = (TextView) view.findViewById(R.id.title);
            statusTextView = (TextView) view.findViewById(R.id.status);
            createdUtcTextView = (TextView) view.findViewById(R.id.createdUtc);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + titleTextView.getText() + "'";
        }
    }
}
