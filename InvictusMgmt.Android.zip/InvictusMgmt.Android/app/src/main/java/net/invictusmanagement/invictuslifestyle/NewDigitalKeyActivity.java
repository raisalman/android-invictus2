package net.invictusmanagement.invictuslifestyle;

import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NavUtils;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static android.Manifest.permission.READ_CONTACTS;

public class NewDigitalKeyActivity extends BaseActivity {

    private class ContactHelper {
        public String name;
        public String email;

        @Override
        public String toString() {
            return name + " (" + email + ")";
        }
    }

    private static final int REQUEST_READ_CONTACTS = 0;

    private AutoCompleteTextView _recipientEditText;
    private EditText _emailEditText;
    private Calendar _fromDateTime;
    private EditText _fromDateEditText;
    private EditText _fromTimeEditText;
    private Calendar _toDateTime;
    private EditText _toDateEditText;
    private EditText _toTimeEditText;
    private EditText _notesEditText;
    private ProgressBar _progressBar;
    private Boolean _changesMade = false;
    private TextWatcher _watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            _changesMade = true;
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_digital_key);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        _fromDateTime = Calendar.getInstance();
        _toDateTime = Calendar.getInstance();
        _toDateTime.add(Calendar.DATE, 1);

        _emailEditText = (EditText) findViewById(R.id.email);

        _recipientEditText = (AutoCompleteTextView) findViewById(R.id.recipent);
        _recipientEditText.addTextChangedListener(_watcher);
        _recipientEditText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ContactHelper helper = (ContactHelper) parent.getAdapter().getItem(position);
                _recipientEditText.setText(helper.name);
                _emailEditText.setText(helper.email);
            }
        });
        populateAutoComplete();

        _fromDateEditText = (EditText) findViewById(R.id.from_date);
        _fromDateEditText.setInputType(InputType.TYPE_NULL);
        _fromDateEditText.setText(SimpleDateFormat.getDateInstance(DateFormat.SHORT).format(_fromDateTime.getTime()));
        _fromDateEditText.addTextChangedListener(_watcher);
        _fromDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utilities.showDatePicker(NewDigitalKeyActivity.this, _fromDateTime, new Utilities.onDateTimePickerChangedListener() {
                    @Override
                    public void dateTimeChanged(Calendar date) {
                        _fromDateTime = date;
                        _fromDateEditText.setText(SimpleDateFormat.getDateInstance(DateFormat.SHORT).format(date.getTime()));

                        _toDateTime = _fromDateTime;
                        _toDateTime.add(Calendar.DATE, 1);
                        _toDateEditText.setText(SimpleDateFormat.getDateInstance(DateFormat.SHORT).format(_toDateTime.getTime()));
                    }
                });
            }
        });
        _fromTimeEditText = (EditText) findViewById(R.id.from_time);
        _fromTimeEditText.setInputType(InputType.TYPE_NULL);
        _fromTimeEditText.setText(SimpleDateFormat.getTimeInstance(DateFormat.SHORT).format(_fromDateTime.getTime()));
        _fromTimeEditText.addTextChangedListener(_watcher);
        _fromTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utilities.showTimePicker(NewDigitalKeyActivity.this, _fromDateTime, new Utilities.onDateTimePickerChangedListener() {
                    @Override
                    public void dateTimeChanged(Calendar date) {
                        _fromDateTime = date;
                        _fromTimeEditText.setText(SimpleDateFormat.getTimeInstance(DateFormat.SHORT).format(date.getTime()));

                        _toDateTime = _fromDateTime;
                        _toDateTime.add(Calendar.DATE, 1);
                        _toTimeEditText.setText(SimpleDateFormat.getTimeInstance(DateFormat.SHORT).format(_toDateTime.getTime()));
                    }
                });
            }
        });

        _toDateEditText = (EditText) findViewById(R.id.to_date);
        _toDateEditText.setInputType(InputType.TYPE_NULL);
        _toDateEditText.setText(SimpleDateFormat.getDateInstance(DateFormat.SHORT).format(_toDateTime.getTime()));
        _toDateEditText.addTextChangedListener(_watcher);
        _toDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utilities.showDatePicker(NewDigitalKeyActivity.this, _fromDateTime, new Utilities.onDateTimePickerChangedListener() {
                    @Override
                    public void dateTimeChanged(Calendar date) {
                        _toDateTime = date;
                        _toDateEditText.setText(SimpleDateFormat.getDateInstance(DateFormat.SHORT).format(date.getTime()));
                    }
                });
            }
        });
        _toTimeEditText = (EditText) findViewById(R.id.to_time);
        _toTimeEditText.setInputType(InputType.TYPE_NULL);
        _toTimeEditText.setText(SimpleDateFormat.getTimeInstance(DateFormat.SHORT).format(_toDateTime.getTime()));
        _toTimeEditText.addTextChangedListener(_watcher);
        _toTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utilities.showTimePicker(NewDigitalKeyActivity.this, _fromDateTime, new Utilities.onDateTimePickerChangedListener() {
                    @Override
                    public void dateTimeChanged(Calendar date) {
                        _toDateTime = date;
                        _toTimeEditText.setText(SimpleDateFormat.getTimeInstance(DateFormat.SHORT).format(date.getTime()));
                    }
                });
            }
        });

        _notesEditText = (EditText) findViewById(R.id.notes);
        _notesEditText.addTextChangedListener(_watcher);
        _progressBar = (ProgressBar) findViewById(R.id.progress);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_send, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (_changesMade)
                    Utilities.showDiscardChangesDialog(this);
                else
                    NavUtils.navigateUpFromSameTask(NewDigitalKeyActivity.this);
                return true;

            case R.id.action_send:
                item.setEnabled(false);
                boolean cancel = false;
                View focusView = null;

                _recipientEditText.setError(null);
                _emailEditText.setError(null);
                _fromDateEditText.setError(null);
                _fromTimeEditText.setError(null);
                _toDateEditText.setError(null);
                _toTimeEditText.setError(null);

                if (TextUtils.isEmpty(_recipientEditText.getText().toString())) {
                    _recipientEditText.setError(getString(R.string.error_field_required));
                    focusView = _recipientEditText;
                    cancel = true;
                } else if (TextUtils.isEmpty(_emailEditText.getText().toString())) {
                    _emailEditText.setError(getString(R.string.error_field_required));
                    focusView = _emailEditText;
                    cancel = true;
                } else if (!Utilities.isValidEmail(_emailEditText.getText())) {
                    _emailEditText.setError(getString(R.string.error_invalid_email));
                    focusView = _emailEditText;
                    cancel = true;
                } else if (TextUtils.isEmpty(_fromDateEditText.getText().toString())) {
                    _fromDateEditText.setError(getString(R.string.error_field_required));
                    focusView = _fromDateEditText;
                    cancel = true;
                } else if (TextUtils.isEmpty(_fromTimeEditText.getText().toString())) {
                    _fromTimeEditText.setError(getString(R.string.error_field_required));
                    focusView = _fromTimeEditText;
                    cancel = true;
                } else if (TextUtils.isEmpty(_toDateEditText.getText().toString())) {
                    _toDateEditText.setError(getString(R.string.error_field_required));
                    focusView = _toDateEditText;
                    cancel = true;
                } else if (TextUtils.isEmpty(_toTimeEditText.getText().toString())) {
                    _toTimeEditText.setError(getString(R.string.error_field_required));
                    focusView = _toTimeEditText;
                    cancel = true;
                } else if (convertToDateTime(_fromDateEditText.getText() + " " + _fromTimeEditText.getText()) == null) {
                    _fromDateEditText.setError(getString(R.string.error_invalid_date_time));
                    focusView = _fromDateEditText;
                    cancel = true;
                } else if (convertToDateTime(_toDateEditText.getText() + " " + _toTimeEditText.getText()) == null) {
                    _toDateEditText.setError(getString(R.string.error_invalid_date_time));
                    focusView = _toDateEditText;
                    cancel = true;
                } else if (convertToDateTime(_fromDateEditText.getText() + " " + _fromTimeEditText.getText()).after(convertToDateTime(_toDateEditText.getText() + " " + _toTimeEditText.getText()))) {
                    _toDateEditText.setError(getString(R.string.error_from_date_time_after_to_date_time));
                    _toTimeEditText.setError(getString(R.string.error_from_date_time_after_to_date_time));
                    focusView = _toDateEditText;
                    cancel = true;
                }

                if (!cancel) {
                    DigitalKey key = new DigitalKey();
                    key.recipient = _recipientEditText.getText().toString();
                    key.email = _emailEditText.getText().toString();
                    key.fromUtc = convertToDateTime(_fromDateEditText.getText() + " " + _fromTimeEditText.getText());
                    key.toUtc = convertToDateTime(_toDateEditText.getText() + " " + _toTimeEditText.getText());
                    key.notes = _notesEditText.getText().toString();

                    new AsyncTask<DigitalKey, Void, Boolean>() {

                        @Override
                        protected void onPreExecute() {
                            Utilities.hideKeyboard(NewDigitalKeyActivity.this);
                            Utilities.showHide(NewDigitalKeyActivity.this, _progressBar, true);
                        }

                        @Override
                        protected Boolean doInBackground(DigitalKey... args) {
                            try {
                                MobileDataProvider.getInstance().createDigitalKey(args[0]);
                                return true;
                            } catch (Exception ex) {
                                Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                                return false;
                            }
                        }

                        @Override
                        protected void onPostExecute(Boolean success) {
                            if (success) {
                                Toast.makeText(NewDigitalKeyActivity.this, "Digital key successfully sent.", Toast.LENGTH_LONG).show();
                                setResult(1);
                                finish();
                            } else {
                                item.setEnabled(true);
                                Toast.makeText(NewDigitalKeyActivity.this, "Digital key creation failed.  Please try again later.", Toast.LENGTH_LONG).show();
                            }
                            Utilities.showHide(NewDigitalKeyActivity.this, _progressBar, false);
                        }

                    }.execute(key);

                } else {
                    focusView.requestFocus();
                    item.setEnabled(true);
                }
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        if (_changesMade)
            Utilities.showDiscardChangesDialog(this);
        else
            super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_READ_CONTACTS) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                populateAutoComplete();
            }
        }
    }

    private void populateAutoComplete() {
        if (!mayRequestContacts()) {
            return;
        }

        ArrayList<ContactHelper> recipients = new ArrayList<>();
        Cursor cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, PROJECTION, null, null, null);
        while (cursor.moveToNext()) {

            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DISPLAY_NAME_PRIMARY));
            String email = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS));
            if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(email)) {
                ContactHelper helper = new ContactHelper();
                helper.name = name;
                helper.email = email;
                recipients.add(helper);
            }
        }
        cursor.close();
        _recipientEditText.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, recipients));
    }

    private boolean mayRequestContacts() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(READ_CONTACTS)) {
            Snackbar.make(_recipientEditText, R.string.permission_rationale, Snackbar.LENGTH_INDEFINITE)
                    .setAction(android.R.string.ok, new View.OnClickListener() {
                        @Override
                        @TargetApi(Build.VERSION_CODES.M)
                        public void onClick(View v) {
                            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
                        }
                    });
        } else {
            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
        }
        return false;
    }

    private Date convertToDateTime(String input) {

        Date result = null;
        try {
            result = SimpleDateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).parse(input);
        } catch (ParseException ex) {
            Log.e(Utilities.TAG, Log.getStackTraceString(ex));
        }
        return result;
    }

    private static final String[] PROJECTION = {
            ContactsContract.CommonDataKinds.Email.DISPLAY_NAME_PRIMARY,
            ContactsContract.CommonDataKinds.Email.ADDRESS
    };
}
