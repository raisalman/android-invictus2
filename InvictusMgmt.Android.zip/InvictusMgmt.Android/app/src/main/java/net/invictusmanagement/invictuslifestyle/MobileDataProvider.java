package net.invictusmanagement.invictuslifestyle;

import android.os.Debug;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

public class MobileDataProvider {

    public interface onForbiddenListener {
        void forbidden();
    }

    private static final String JsonDateFormatString = "yyyy-MM-dd'T'HH:mm:ss";
    private static final int HttpsReadTimeout = 30000;
    private static final int HttpsConnectTimeout = 10000;

    private static MobileDataProvider _instance = new MobileDataProvider();
    private String _baseUrl;
    private String _authenticationCookie = null;
    private onForbiddenListener _onForbiddenListener;

    private MobileDataProvider() {
        _baseUrl = Debug.isDebuggerConnected() ? "https://mobiledev.invictusmanagement.net/" : "https://mobile.invictusmanagement.net/";
    }

    public static MobileDataProvider getInstance() {
        return _instance;
    }

    public void setAuthenticationCookie(String cookie) {
        _authenticationCookie = cookie;
    }

    public void setOnForbiddenListener(onForbiddenListener listener) {
        _onForbiddenListener = listener;
    }

    public AuthenticationResult authenticate(String email, String activationCode) throws IOException, ForbiddenException {

        AuthenticationResult result = new AuthenticationResult();
        HttpsURLConnection https = null;
        try {
            Log.d(Utilities.TAG, "Authenticating");
            URL url = new URL(_baseUrl + "api/v1/account/login");
            https = (HttpsURLConnection) url.openConnection();
            https.setReadTimeout(HttpsReadTimeout);
            https.setConnectTimeout(HttpsConnectTimeout);
            https.setRequestProperty("Content-Type", "application/json");
            https.setRequestProperty("Accept", "application/json");
            https.setRequestMethod("POST");
            https.setDoInput(true);

            Login payload = new Login();
            payload.email = email;
            payload.activationCode = activationCode;
            TimeZone timezone = TimeZone.getDefault();
            payload.timeZoneOffset = timezone.getOffset(Calendar.ZONE_OFFSET) / 1000 / 60;

            https.connect();
            OutputStream outputStream = https.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            writer.write(new GsonBuilder().create().toJson(payload));
            writer.flush();
            writer.close();
            outputStream.close();

            int responseCode = https.getResponseCode();
            Log.d(Utilities.TAG, "Authenticate returned: " + Integer.toString(responseCode));
            if (responseCode == HttpsURLConnection.HTTP_OK) {

                StringBuilder json = new StringBuilder();
                InputStream inputStream = https.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = reader.readLine()) != null) {
                    json.append(line);
                }
                reader.close();
                inputStream.close();
                result.userId = Long.parseLong(json.toString());

                CookieManager cookieManager = new java.net.CookieManager();
                Map<String, List<String>> headerFields = https.getHeaderFields();
                List<String> cookiesHeader = headerFields.get("Set-Cookie");

                if (cookiesHeader != null) {
                    for (String cookie : cookiesHeader) {
                        if (cookie.contains("AspNetCore.MobileIdentity.Application")) {
                            result.authenticationCookie = cookie;
                            break;
                        }
                    }
                }
            } else if (responseCode == HttpURLConnection.HTTP_FORBIDDEN) {
                if (_onForbiddenListener != null)
                    _onForbiddenListener.forbidden();
                throw new ForbiddenException();
            } else
                throw new IOException("Invalid response code.  Code: " + Integer.toString(responseCode));

        } finally {
            if (https != null)
                https.disconnect();
        }
        return result;
    }

    public User getUser() throws IOException, ForbiddenException {
        String json = get("api/v1/account/profile");
        return new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer()).create().fromJson(json, new TypeToken<User>() {
        }.getType());
    }

    public ChatToken getChatToken(String room) throws IOException, ForbiddenException {

        String json = get("api/v1/chat?room=" + room);
        return new Gson().fromJson(json, new TypeToken<ChatToken>() {
        }.getType());
    }

    public List<AccessPoint> getAccessPoints() throws IOException, ForbiddenException {

        String json = get("api/v1/accesspoints");
        return new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer()).create().fromJson(json, new TypeToken<List<AccessPoint>>() {
        }.getType());
    }

    public List<BusinessType> getBusinessTypes() throws IOException, ForbiddenException {

        String json = get("api/v1/businesses/types");
        return new Gson().fromJson(json, new TypeToken<List<BusinessType>>() {
        }.getType());
    }

    public List<Business> getBusinesses(BusinessType item) throws IOException, ForbiddenException {

        String json = get("api/v1/businesses/" + Integer.toString(item.id));
        return new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer()).create().fromJson(json, new TypeToken<List<Business>>() {
        }.getType());
    }

    public List<Notification> getNotifications() throws IOException, ForbiddenException {

        String json = get("api/v1/notifications");
        return new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer()).create().fromJson(json, new TypeToken<List<Notification>>() {
        }.getType());
    }

    public List<MaintenanceRequest> getMaintenanceRequests() throws IOException, ForbiddenException {

        String json = get("api/v1/maintenancerequests");
        return new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer()).create().fromJson(json, new TypeToken<List<MaintenanceRequest>>() {
        }.getType());
    }

    public List<DigitalKey> getDigitalKeys() throws IOException, ForbiddenException {

        String json = get("api/v1/digitalkeys");
        return new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer()).create().fromJson(json, new TypeToken<List<DigitalKey>>() {
        }.getType());
    }

    public void createDigitalKey(DigitalKey item) throws IOException, ForbiddenException {

        String json = new GsonBuilder().registerTypeAdapter(Date.class, new DateSerializer()).create().toJson(item);
        putOrPost(false, "api/v1/digitalkeys", json);
    }

    public void createMaintenanceRequest(MaintenanceRequest item) throws IOException, ForbiddenException {

        String json = new GsonBuilder().registerTypeAdapter(Date.class, new DateSerializer()).create().toJson(item);
        putOrPost(false, "api/v1/maintenancerequests", json);
    }

    public void createFeedback(Feedback item) throws IOException, ForbiddenException {

        String json = new GsonBuilder().registerTypeAdapter(Date.class, new DateSerializer()).create().toJson(item);
        putOrPost(false, "api/v1/feedback", json);
    }

    public void updateUser(UserUpdate item) throws IOException, ForbiddenException {
        String json = new GsonBuilder().registerTypeAdapter(Date.class, new DateSerializer()).create().toJson(item);
        putOrPost(true, "api/v1/account/profile", json);
    }

    public void updateDigitalKey(DigitalKeyUpdate item) throws IOException, ForbiddenException {
        String json = new GsonBuilder().registerTypeAdapter(Date.class, new DateSerializer()).create().toJson(item);
        putOrPost(true, "api/v1/digitalkeys", json);
    }

    public void openAccessPoint(OpenAccessPoint item) throws IOException, ForbiddenException {

        String json = new GsonBuilder().create().toJson(item);
        putOrPost(false, "api/v1/accesspoints", json);
    }

    public void sendToVoiceMail(long accessPointId) throws IOException, ForbiddenException {

        String json = new GsonBuilder().create().toJson(accessPointId);
        putOrPost(false, "api/v1/chat", json);
    }

    private String get(String path) throws IOException, ForbiddenException {

        StringBuilder json = new StringBuilder();
        HttpsURLConnection https = null;
        try {
            Log.d(Utilities.TAG, "Executing Https Get: " + _baseUrl + path);
            URL url = new URL(_baseUrl + path);
            https = (HttpsURLConnection) url.openConnection();
            https.setReadTimeout(HttpsReadTimeout);
            https.setConnectTimeout(HttpsConnectTimeout);
            if (!TextUtils.isEmpty(_authenticationCookie)) {
                https.setRequestProperty("Cookie", _authenticationCookie);
            }
            https.connect();
            int responseCode = https.getResponseCode();
            Log.d(Utilities.TAG, "Https Get returned: " + Integer.toString(responseCode));
            if (responseCode == HttpURLConnection.HTTP_FORBIDDEN) {
                if (_onForbiddenListener != null)
                    _onForbiddenListener.forbidden();
                throw new ForbiddenException();
            } else if (responseCode != HttpsURLConnection.HTTP_OK && responseCode != HttpsURLConnection.HTTP_CREATED)
                throw new IOException("Invalid response code.  Code: " + Integer.toString(responseCode));

            InputStream stream = https.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            String line;
            while ((line = reader.readLine()) != null) {
                json.append(line);
            }
            reader.close();
            stream.close();
        } finally {
            if (https != null)
                https.disconnect();
        }
        return json.toString();
    }

    private void putOrPost(boolean isPut, String path, String payload) throws IOException, ForbiddenException {

        HttpsURLConnection https = null;
        try {
            Log.d(Utilities.TAG, "Executing Https Put/Post: " + _baseUrl + path);
            URL url = new URL(_baseUrl + path);
            https = (HttpsURLConnection) url.openConnection();
            https.setReadTimeout(HttpsReadTimeout);
            https.setConnectTimeout(HttpsConnectTimeout);
            https.setRequestProperty("Content-Type", "application/json");
            https.setRequestProperty("Accept", "application/json");
            https.setRequestMethod(isPut ? "PUT" : "POST");
            https.setDoInput(true);
            if (!TextUtils.isEmpty(_authenticationCookie)) {
                https.setRequestProperty("Cookie", _authenticationCookie);
            }
            https.connect();
            OutputStream stream = https.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stream, "UTF-8"));
            writer.write(payload);
            writer.flush();
            writer.close();
            stream.close();

            int responseCode = https.getResponseCode();
            Log.d(Utilities.TAG, "Https Put/Post returned: " + Integer.toString(responseCode));
            if (responseCode == HttpURLConnection.HTTP_FORBIDDEN) {
                if (_onForbiddenListener != null)
                    _onForbiddenListener.forbidden();
                throw new ForbiddenException();
            } else if (responseCode != HttpsURLConnection.HTTP_OK && responseCode != HttpsURLConnection.HTTP_CREATED)
                throw new IOException("Invalid response code.  Code: " + Integer.toString(responseCode));
        } finally {
            if (https != null)
                https.disconnect();
        }
    }

    private class DateDeserializer implements JsonDeserializer<Date> {

        @Override
        public Date deserialize(JsonElement element, Type arg1, JsonDeserializationContext arg2) throws JsonParseException {
            String date = element.getAsString();

            SimpleDateFormat formatter = new SimpleDateFormat(JsonDateFormatString);
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));

            try {
                return formatter.parse(date);
            } catch (ParseException ex) {
                Log.e(Utilities.TAG, "JsonDeserializer<Date>() failed", ex);
                return null;
            }
        }
    }

    private class DateSerializer implements JsonSerializer<Date> {

        @Override
        public JsonElement serialize(Date src, Type typeOfSrc, JsonSerializationContext context) {
            SimpleDateFormat formatter = new SimpleDateFormat(JsonDateFormatString);
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
            return new JsonPrimitive(formatter.format(src));
        }
    }
}
