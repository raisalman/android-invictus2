package net.invictusmanagement.invictuslifestyle;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.ViewHolder> {

    private final List<Notification> _dataSource = new ArrayList<>();
    private final NotificationsListFragmentInteractionListener _listener;

    public NotificationsAdapter(NotificationsListFragmentInteractionListener listener) {
        _listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_notification, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.item = _dataSource.get(position);

        holder.iconRoundedLetterView.setTitleText(holder.item.title.substring(0, 1).toUpperCase());
        holder.titleTextView.setText(holder.item.title);
        DateFormat formatter = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT);
        holder.createdUtcTextView.setText(formatter.format(holder.item.createdUtc));

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != _listener) {
                    _listener.onListFragmentInteraction(holder.item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return _dataSource.size();
    }


    public void refresh(List<Notification> list) {
        if (list == null) return;
        _dataSource.clear();
        _dataSource.addAll(list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View view;
        public final RoundedLetterView iconRoundedLetterView;
        public final TextView titleTextView;
        public final TextView createdUtcTextView;
        public Notification item;

        public ViewHolder(View view) {
            super(view);
            this.view = view;
            iconRoundedLetterView = (RoundedLetterView) view.findViewById(R.id.icon);
            titleTextView = (TextView) view.findViewById(R.id.title);
            createdUtcTextView = (TextView) view.findViewById(R.id.createdUtc);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + titleTextView.getText() + "'";
        }
    }
}
