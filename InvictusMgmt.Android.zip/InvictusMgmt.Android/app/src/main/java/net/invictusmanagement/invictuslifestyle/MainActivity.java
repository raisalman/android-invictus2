package net.invictusmanagement.invictuslifestyle;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;

import android.util.Log;
import android.widget.Toast;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String authenticationCookie = sharedPreferences.getString("authenticationCookie", null);
        if (authenticationCookie == null) {
            startActivity(new Intent(this, LoginActivity.class));
        } else {
            MobileDataProvider.getInstance().setAuthenticationCookie(authenticationCookie);
            Intent intent = getIntent();
            if (Intent.ACTION_VIEW.equals(intent.getAction())) {
                Uri uri = intent.getData();
                if (uri.getHost().equals("accesspoint") && uri.getQueryParameter("id").length() > 0 && uri.getQueryParameter("name").length() > 0) {
                    Long id = Long.parseLong(uri.getQueryParameter("id"));
                    final String name = uri.getQueryParameter("name");
                    new AsyncTask<Long, Void, Boolean>() {

                        @Override
                        protected Boolean doInBackground(Long... params) {
                            try {
                                OpenAccessPoint model = new OpenAccessPoint();
                                model.id = params[0];
                                model.isSilent = true;
                                MobileDataProvider.getInstance().openAccessPoint(model);
                                return true;
                            } catch (Exception ex) {
                                Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                                return false;
                            }
                        }

                        @Override
                        protected void onPostExecute(Boolean success) {
                            if (success)
                                Toast.makeText(MainActivity.this, name + " was successfully opened.", Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(MainActivity.this, "Opening the " + name + " access point failed.  Please try again later.", Toast.LENGTH_LONG).show();
                        }
                    }.execute(id);
                }   // Valid access point id?
                else {
                    Toast.makeText(MainActivity.this, "Invalid access point information detected.  Please try again later.", Toast.LENGTH_LONG).show();
                }
            } else {
                startActivity(new Intent(this, TabbedActivity.class));
            }
        }
        finish();
    }
}
