package net.invictusmanagement.invictuslifestyle;

interface IRefreshableFragment {

    void refresh();
}
