package net.invictusmanagement.invictuslifestyle;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class PromotionsAdapter extends RecyclerView.Adapter<PromotionsAdapter.ViewHolder> {

    private final List<Promotion> _dataSource = new ArrayList<>();
    private final PromotionsListFragmentInteractionListener _listener;

    public PromotionsAdapter(PromotionsListFragmentInteractionListener listener) {
        _listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_promotion, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.item = _dataSource.get(position);

        holder.iconRoundedLetterView.setTitleText(holder.item.name.substring(0, 1).toUpperCase());
        holder.nameTextView.setText(holder.item.name);
        DateFormat formatter = SimpleDateFormat.getDateInstance(DateFormat.FULL);
        holder.toUtcTextView.setText(formatter.format(holder.item.toUtc));
        holder.descriptionTextView.setText(holder.item.description);

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != _listener) {
                    _listener.onListFragmentInteraction(holder.item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return _dataSource.size();
    }


    public void refresh(List<Promotion> list) {
        _dataSource.clear();
        _dataSource.addAll(list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View view;
        public final RoundedLetterView iconRoundedLetterView;
        public final TextView nameTextView;
        public final TextView toUtcTextView;
        public final TextView descriptionTextView;
        public Promotion item;

        public ViewHolder(View view) {
            super(view);
            this.view = view;
            iconRoundedLetterView = (RoundedLetterView) view.findViewById(R.id.icon);
            nameTextView = (TextView) view.findViewById(R.id.name);
            toUtcTextView = (TextView) view.findViewById(R.id.toUtc);
            descriptionTextView = (TextView) view.findViewById(R.id.description);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + nameTextView.getText() + "'";
        }
    }
}
