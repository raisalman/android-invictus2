package net.invictusmanagement.invictuslifestyle;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DigitalKeysAdapter extends RecyclerView.Adapter<DigitalKeysAdapter.ViewHolder> {

    private Context _context;
    private final List<DigitalKey> _dataSource = new ArrayList<>();
    private final DigitalKeysListFragmentInteractionListener _listener;

    public DigitalKeysAdapter(Context context, DigitalKeysListFragmentInteractionListener listener) {
        _context = context;
        _listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_digitalkey, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.item = _dataSource.get(position);

        try {
            Long l = Long.parseLong(holder.item.recipient);
            holder.recipientTextView.setText(Utilities.formatPhone(holder.item.recipient));
        } catch (NumberFormatException ex) {
            holder.recipientTextView.setText(holder.item.recipient);
        }

        Date now = new Date();
        GradientDrawable drawable = (GradientDrawable) holder.iconBackgroundImageView.getDrawable();
        if (holder.item.isRevoked) {
            holder.statusTextView.setText("Revoked");
            holder.iconImageView.setImageResource(R.drawable.ic_block_white_24dp);
            drawable.setColor(ContextCompat.getColor(_context, R.color.digitalKeyExpired));
        } else {
            if (now.after(holder.item.fromUtc) && now.before(holder.item.toUtc)) {
                holder.statusTextView.setText("Valid");
                holder.iconImageView.setImageResource(R.drawable.ic_check_white_24dp);
                drawable.setColor(ContextCompat.getColor(_context, R.color.digitalKeyValid));
            } else if (now.before(holder.item.fromUtc) && now.before(holder.item.toUtc)) {
                holder.statusTextView.setText("Upcoming");
                holder.iconImageView.setImageResource(R.drawable.ic_hourglass_empty_white_24dp);
                drawable.setColor(ContextCompat.getColor(_context, R.color.digitalKeyUpcoming));
            } else {
                holder.statusTextView.setText("Expired");
                holder.iconImageView.setImageResource(R.drawable.ic_block_white_24dp);
                drawable.setColor(ContextCompat.getColor(_context, R.color.digitalKeyExpired));
            }
        }   // revoked?

        DateFormat formatter = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT);
        holder.fromTextView.setText(formatter.format(holder.item.fromUtc));
        holder.toTextView.setText(formatter.format(holder.item.toUtc));

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != _listener) {
                    _listener.onListFragmentInteraction(holder.item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return _dataSource.size();
    }

    public void refresh(List<DigitalKey> list) {
        if (list == null) return;
        _dataSource.clear();
        _dataSource.addAll(list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View view;
        public final ImageView iconBackgroundImageView;
        public final ImageView iconImageView;
        public final TextView recipientTextView;
        public final TextView statusTextView;
        public final TextView fromTextView;
        public final TextView toTextView;
        public DigitalKey item;

        public ViewHolder(View view) {
            super(view);
            this.view = view;
            iconBackgroundImageView = (ImageView) view.findViewById(R.id.icon_background);
            iconImageView = (ImageView) view.findViewById(R.id.icon);
            recipientTextView = (TextView) view.findViewById(R.id.recipient);
            statusTextView = (TextView) view.findViewById(R.id.status);
            fromTextView = (TextView) view.findViewById(R.id.from);
            toTextView = (TextView) view.findViewById(R.id.to);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + recipientTextView.getText() + "'";
        }
    }
}
