package net.invictusmanagement.invictuslifestyle;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class NewMaintenanceRequestActivity extends BaseActivity {

    private EditText _titleEditText;
    private EditText _descriptionEditText;
    private ProgressBar _progressBar;
    private Boolean _changesMade = false;
    private TextWatcher _watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            _changesMade = true;
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_maintenance_request);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        _titleEditText = (EditText) findViewById(R.id.title);
        _titleEditText.addTextChangedListener(_watcher);

        _descriptionEditText = (EditText) findViewById(R.id.description);
        _descriptionEditText.addTextChangedListener(_watcher);

        _progressBar = (ProgressBar) findViewById(R.id.progress);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_send, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (_changesMade)
                    Utilities.showDiscardChangesDialog(this);
                else
                    NavUtils.navigateUpFromSameTask(NewMaintenanceRequestActivity.this);
                return true;

            case R.id.action_send:
                item.setEnabled(false);
                boolean cancel = false;
                View focusView = null;

                _titleEditText.setError(null);
                _descriptionEditText.setError(null);

                if (TextUtils.isEmpty(_titleEditText.getText().toString())) {
                    _titleEditText.setError(getString(R.string.error_field_required));
                    focusView = _titleEditText;
                    cancel = true;
                } else if (TextUtils.isEmpty(_descriptionEditText.getText().toString())) {
                    _descriptionEditText.setError(getString(R.string.error_field_required));
                    focusView = _descriptionEditText;
                    cancel = true;
                }

                if (!cancel) {
                    MaintenanceRequest request = new MaintenanceRequest();
                    request.title = _titleEditText.getText().toString();
                    request.description = _descriptionEditText.getText().toString();

                    new AsyncTask<MaintenanceRequest, Void, Boolean>() {

                        @Override
                        protected void onPreExecute() {
                            Utilities.hideKeyboard(NewMaintenanceRequestActivity.this);
                            Utilities.showHide(NewMaintenanceRequestActivity.this, _progressBar, true);
                        }

                        @Override
                        protected Boolean doInBackground(MaintenanceRequest... args) {
                            try {
                                MobileDataProvider.getInstance().createMaintenanceRequest(args[0]);
                                return true;
                            } catch (Exception ex) {
                                Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                                return false;
                            }
                        }

                        @Override
                        protected void onPostExecute(Boolean success) {
                            if (success) {
                                Toast.makeText(NewMaintenanceRequestActivity.this, "Maintenance request successfully sent.", Toast.LENGTH_LONG).show();
                                setResult(1);
                                finish();
                            } else {
                                item.setEnabled(true);
                                Toast.makeText(NewMaintenanceRequestActivity.this, "Maintenance request creation failed.  Please try again later.", Toast.LENGTH_LONG).show();
                            }
                            Utilities.showHide(NewMaintenanceRequestActivity.this, _progressBar, false);
                        }

                    }.execute(request);

                } else {
                    item.setEnabled(true);
                    focusView.requestFocus();
                }
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        if (_changesMade)
            Utilities.showDiscardChangesDialog(this);
        else
            super.onBackPressed();
    }
}
