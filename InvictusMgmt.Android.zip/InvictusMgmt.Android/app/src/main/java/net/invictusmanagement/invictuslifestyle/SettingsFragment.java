package net.invictusmanagement.invictuslifestyle;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class SettingsFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {

    private SwitchPreference _doNotDisturbSwitch;
    private User _user;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.xml.pref_general);
        _doNotDisturbSwitch = (SwitchPreference) findPreference("dnd_switch");

        new AsyncTask<Void, Void, User>() {

            @Override
            protected void onPreExecute() {
            }

            @Override
            protected User doInBackground(Void... args) {
                try {
                    return MobileDataProvider.getInstance().getUser();
                } catch (Exception ex) {
                    Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                    return null;
                }
            }

            @Override
            protected void onPostExecute(User user) {
                if (user != null) {
                    _user = user;
                    _doNotDisturbSwitch.setChecked(user.isDoNotDisturb);
                    _doNotDisturbSwitch.setEnabled(true);

                    findPreference("displayName").setSummary(user.displayName);
                    findPreference("email").setSummary(user.email);
                    findPreference("phone").setSummary(Utilities.formatPhone(user.phoneNumber));
                    findPreference("locationName").setSummary(user.locationName);
                    DateFormat formatter = SimpleDateFormat.getDateInstance(DateFormat.FULL);
                    findPreference("leaseRenewalDateUtc").setSummary(formatter.format(user.leaseRenewalDateUtc));
                } else {
                    Toast.makeText(getActivity(), "Unable to refresh current user. Please try again later.", Toast.LENGTH_LONG).show();
                }
                SharedPreferences prefs = getPreferenceScreen().getSharedPreferences();
                prefs.registerOnSharedPreferenceChangeListener(SettingsFragment.this);
                onSharedPreferenceChanged(prefs, "chat_ringtone");
            }
        }.execute();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        PreferenceManager.setDefaultValues(context, R.xml.pref_general, false);
    }

    @Override
    public void onDestroy() {
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }

    @Override
    public void onSharedPreferenceChanged(final SharedPreferences sharedPreferences, final String key) {

        if (key.equals("chat_ringtone")) {
            Preference pref = findPreference(key);
            String ringtoneName = sharedPreferences.getString(key, "");
            if (TextUtils.isEmpty(ringtoneName)) {
                pref.setSummary(R.string.pref_ringtone_silent);
            } else {
                Ringtone ringtone = RingtoneManager.getRingtone(pref.getContext(), Uri.parse(ringtoneName));
                pref.setSummary(ringtone == null ? null : ringtone.getTitle(pref.getContext()));
            }
        } else if (key.equals("dnd_switch")) {

            // NOTE: This preference is only enabled if we successfully fetch out user profile data so _user should never be null.
            new AsyncTask<Void, Void, Boolean>() {

                @Override
                protected void onPreExecute() {
                }

                @Override
                protected Boolean doInBackground(Void... args) {
                    try {
                        UserUpdate model = new UserUpdate();
                        model.isDoNotDisturb = _doNotDisturbSwitch.isChecked();
                        MobileDataProvider.getInstance().updateUser(model);
                        _user.isDoNotDisturb = model.isDoNotDisturb;
                        return true;
                    } catch (Exception ex) {
                        Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                        return false;
                    }
                }

                @Override
                protected void onPostExecute(Boolean success) {
                    if (!success)
                        Toast.makeText(getActivity(), "Unable to save profile. Please try again later.", Toast.LENGTH_LONG).show();
                }

            }.execute();
        }
    }
}
