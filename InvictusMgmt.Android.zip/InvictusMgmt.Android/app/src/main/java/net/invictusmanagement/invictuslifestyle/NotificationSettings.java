package net.invictusmanagement.invictuslifestyle;

import android.os.Debug;

class NotificationSettings {

    public static String SenderId = "200573005109";

    public static String HubName = "videochathub";

    public static String HubListenConnectionString = Debug.isDebuggerConnected() ? "Endpoint=sb://invictusdev.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=5r9ygxc8RUOgJ+olDBw3ogAM3+hKWpPYv3vZl5YCESI=" :
            "Endpoint=sb://invictus.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=NplWa4Qt5/wEWAUPasaC0ZuaveafkZw9hi4bOhZaOzo=";
}
