package net.invictusmanagement.invictuslifestyle;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AccessPointsAdapter extends RecyclerView.Adapter<AccessPointsAdapter.ViewHolder> {

    private Context _context;
    private final List<AccessPoint> _dataSource = new ArrayList<>();
    private final AccessPointsListFragmentInteractionListener _listener;

    public AccessPointsAdapter(Context context, AccessPointsListFragmentInteractionListener listener) {
        _context = context;
        _listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_accesspoint, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.item = _dataSource.get(position);

        GradientDrawable drawable = (GradientDrawable) holder.iconBackgroundImageView.getDrawable();
        drawable.setColor(ContextCompat.getColor(_context, R.color.colorPrimary));
        holder.iconImageView.setImageResource(holder.item.type == AccessPoint.Type.Pedestrian ? R.drawable.ic_directions_walk_white_24dp : R.drawable.ic_directions_car_white_24dp);
        holder.nameTextView.setText(holder.item.name);
        holder.typeTextView.setText(holder.item.type.toString());

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != _listener) {
                    _listener.onListFragmentInteraction(holder.item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return _dataSource.size();
    }

    public void refresh(List<AccessPoint> list) {
        if (list == null) return;
        _dataSource.clear();
        _dataSource.addAll(list);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View view;
        public final ImageView iconBackgroundImageView;
        public final ImageView iconImageView;
        public final TextView nameTextView;
        public final TextView typeTextView;
        public AccessPoint item;

        public ViewHolder(View view) {
            super(view);
            this.view = view;
            iconBackgroundImageView = (ImageView) view.findViewById(R.id.icon_background);
            iconImageView = (ImageView) view.findViewById(R.id.icon);
            nameTextView = (TextView) view.findViewById(R.id.name);
            typeTextView = (TextView) view.findViewById(R.id.type);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + nameTextView.getText() + "'";
        }
    }
}
