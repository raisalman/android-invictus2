package net.invictusmanagement.invictuslifestyle;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.microsoft.windowsazure.notifications.NotificationsHandler;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class ChatNotificationHandler extends NotificationsHandler {

    @Override
    public void onReceive(Context context, Bundle bundle) {

        Log.d(Utilities.TAG, "Push notification received.");

        boolean startActivity = true;

        String validUntilDateUtc = bundle.getString("validUntilDateUtc");
        if (!TextUtils.isEmpty(validUntilDateUtc)) {
            try {
                Log.d(Utilities.TAG, "Checking age of notification: " + validUntilDateUtc);
                // This date format is specified on the server.
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
                ParsePosition parsePosition = new ParsePosition(0);
                Date validUntilDateLocal = formatter.parse(validUntilDateUtc, parsePosition);
                startActivity = new Date().before(validUntilDateLocal);
            } catch (Exception ex) {
                Log.e(Utilities.TAG, Log.getStackTraceString(ex));
            }
        }   // valid until date empty?

        if (startActivity) {
            Log.d(Utilities.TAG, "Starting chat activity.");
            Intent intent = new Intent(context, ChatActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            intent.putExtra(ChatActivity.EXTRA_ACCESS_POINT_ID, bundle.getString("id"));
            intent.putExtra(ChatActivity.EXTRA_CALLER_NAME, bundle.getString("caller"));
            intent.putExtra(ChatActivity.EXTRA_ACCESSPOINT_NAME, bundle.getString("accessPointName"));
            intent.putExtra(ChatActivity.EXTRA_ROOM_ID, bundle.getString("room"));
            context.startActivity(intent);
        }   // start activity?
    }

    /*
    private void sendNotification(String msg) {

        Intent intent = new Intent(ctx, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        mNotificationManager = (NotificationManager)
                ctx.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(ctx, 0,
                intent, PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(ctx)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle("Notification Hub Demo")
                        .setStyle(new NotificationCompat.BigTextStyle()
                                .bigText(msg))
                        .setSound(defaultSoundUri)
                        .setContentText(msg);

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
    }
    */
}
