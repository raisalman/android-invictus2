package net.invictusmanagement.invictuslifestyle;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class PromotionsActivity extends BaseActivity implements PromotionsListFragmentInteractionListener {

    public static final String EXTRA_BUSINESS_JSON = "net.invictusmanagement.invictusmobile.business";

    private Business _business;
    private RecyclerView _recyclerView;
    private PromotionsAdapter _adapter;
    private SwipeRefreshLayout _swipeRefreshLayout;
    private TextView _feedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promotions);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        _business = new Gson().fromJson(getIntent().getStringExtra(EXTRA_BUSINESS_JSON), new TypeToken<Business>() {
        }.getType());

        if (!TextUtils.isEmpty(_business.name))
            setTitle(_business.name + " Coupons");

        _feedback = (TextView) findViewById(R.id.feedback);
        _recyclerView = (RecyclerView) findViewById(R.id.list);
        _recyclerView.setHasFixedSize(true);
        _recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
        _adapter = new PromotionsAdapter(this);
        _recyclerView.setAdapter(_adapter);

        _swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh);
        _swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(this, R.color.colorPrimary));
        _swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        });
        refresh();
    }

    @Override
    public void onListFragmentInteraction(Promotion item) {

    }

    public void refresh() {
        if (_swipeRefreshLayout == null || _adapter == null)
            return;

        new AsyncTask<Void, Void, Boolean>() {

            @Override
            protected void onPreExecute() {
                _swipeRefreshLayout.setRefreshing(true);
            }

            @Override
            protected Boolean doInBackground(Void... args) {
                try {
                    _adapter.refresh(_business.promotions);
                    return true;
                } catch (Exception ex) {
                    Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean success) {
                _adapter.notifyDataSetChanged();
                _swipeRefreshLayout.setRefreshing(false);
                Utilities.showHide(PromotionsActivity.this, _feedback, _adapter.getItemCount() <= 0);
                Utilities.showHide(PromotionsActivity.this, _recyclerView, _adapter.getItemCount() > 0);
                if (!success)
                    Toast.makeText(PromotionsActivity.this, "Unable to refresh coupons. Please try again later.", Toast.LENGTH_LONG).show();
            }
        }.execute();
    }
}
