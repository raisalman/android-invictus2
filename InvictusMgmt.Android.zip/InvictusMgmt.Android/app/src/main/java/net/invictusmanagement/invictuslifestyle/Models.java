package net.invictusmanagement.invictuslifestyle;

import com.google.gson.annotations.SerializedName;

import java.util.Date;
import java.util.List;

class ModelBase {
    public long id;
    public Date createdUtc;
}

class AuthenticationResult {
    long userId;
    String authenticationCookie;
}

class AccessPoint extends ModelBase {

    public enum Type {

        @SerializedName("1")
        Pedestrian(1),

        @SerializedName("2")
        Vehicle(2);

        private final int value;

        public int getValue() {
            return value;
        }

        Type(int value) {
            this.value = value;
        }
    }

    public String name;
    public Type type;
}

class BusinessType {
    public int id;
    public String name;
}

class ChatToken {
    public String token;
}

class DigitalKey extends ModelBase {
    public Date fromUtc;
    public Date toUtc;
    public String recipient;
    public String email;
    public String notes;
    public boolean isRevoked;
}

class DigitalKeyUpdate {
    public long id;
    public boolean isRevoked;
}

class Feedback extends ModelBase {

    public enum Type {

        @SerializedName("1")
        Bug(1),

        @SerializedName("2")
        Enhancement(2),

        @SerializedName("3")
        General(3);

        private final int value;

        public int getValue() {
            return value;
        }

        Type(int value) {
            this.value = value;
        }
    }

    public String message;
    public Type type;
}

class MaintenanceRequest extends ModelBase {

    public enum Status {

        @SerializedName("1")
        Active(1),

        @SerializedName("2")
        Closed(2),

        @SerializedName("3")
        Requested(3);

        private final int value;

        public int getValue() {
            return value;
        }

        Status(int value) {
            this.value = value;
        }
    }

    public Date closedUtc;
    public String title;
    public String description;
    public Status status;
}

class Notification extends ModelBase {
    public String title;
    public String message;
}

class OpenAccessPoint {
    public long id;
    public Boolean isSilent;
}

class Business extends ModelBase {
    public String name;
    public String address1;
    public String address2;
    public String city;
    public String state;
    public String zip;
    public String phone;
    public double latitude;
    public double longitude;
    List<Promotion> promotions;
}


class Promotion extends ModelBase {
    public String name;
    public String description;
    public Date fromUtc;
    public Date toUtc;
}

class User {
    public Date createdUtc;
    public String displayName;
    public String email;
    public boolean isDoNotDisturb;
    public Date leaseRenewalDateUtc;
    public String locationName;
    public String phoneNumber;
    public String unitNbr;
}

class UserUpdate {
    public boolean isDoNotDisturb;
}

class Login {
    public String email;
    public String activationCode;
    public int timeZoneOffset;
}
