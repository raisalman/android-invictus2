package net.invictusmanagement.invictuslifestyle;

public class ForbiddenException extends Exception {

    public ForbiddenException() {
        super();
    }
}
