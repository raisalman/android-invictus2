package net.invictusmanagement.invictuslifestyle;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class AccessPointsFragment extends Fragment implements IRefreshableFragment {

    private AccessPointsListFragmentInteractionListener _listener;
    private RecyclerView _recyclerView;
    private AccessPointsAdapter _adapter;
    private SwipeRefreshLayout _swipeRefreshLayout;
    private Context _context;
    private TextView _feedback;

    public AccessPointsFragment() {
    }

    @SuppressWarnings("unused")
    public static AccessPointsFragment newInstance() {
        return new AccessPointsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_accesspoints_list, container, false);
        if (view instanceof SwipeRefreshLayout) {

            _feedback = (TextView) view.findViewById(R.id.feedback);
            _recyclerView = (RecyclerView) view.findViewById(R.id.list);
            _recyclerView.setHasFixedSize(true);
            _recyclerView.addItemDecoration(new SimpleDividerItemDecoration(_context));
            _adapter = new AccessPointsAdapter(_context, _listener);
            _recyclerView.setAdapter(_adapter);

            _swipeRefreshLayout = (SwipeRefreshLayout) view;
            _swipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(_context, R.color.colorPrimary));
            _swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    refresh();
                }
            });
            refresh();
        }
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        _context = context;
        if (_context instanceof AccessPointsListFragmentInteractionListener) {
            _listener = (AccessPointsListFragmentInteractionListener) _context;
        } else {
            throw new RuntimeException(_context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        _listener = null;
    }

    public void refresh() {
        if (_swipeRefreshLayout == null || _adapter == null)
            return;

        new AsyncTask<Void, Void, Boolean>() {

            @Override
            protected void onPreExecute() {
                _swipeRefreshLayout.setRefreshing(true);
            }

            @Override
            protected Boolean doInBackground(Void... args) {
                try {
                    _adapter.refresh(MobileDataProvider.getInstance().getAccessPoints());
                    return true;
                } catch (Exception ex) {
                    Log.e(Utilities.TAG, Log.getStackTraceString(ex));
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean success) {
                _adapter.notifyDataSetChanged();
                _swipeRefreshLayout.setRefreshing(false);
                Utilities.showHide(_context, _feedback, _adapter.getItemCount() <= 0);
                Utilities.showHide(_context, _recyclerView, _adapter.getItemCount() > 0);
                if (!success)
                    Toast.makeText(getActivity(), "Unable to refresh access points. Please try again later.", Toast.LENGTH_LONG).show();
            }
        }.execute();
    }
}
