package net.invictusmanagement.invictuslifestyle;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import net.hockeyapp.android.CrashManagerListener;
import net.hockeyapp.android.ExceptionHandler;

import java.util.Calendar;

public class Utilities {

    public static final String TAG = "InvictusMobile";
    private static CrashManagerListener _crashManagerListener;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;

    public static String formatPhone(String phone) {
        if (phone.length() == 10) {
            return "(" + phone.substring(0, 3) + ") " + phone.substring(3, 6) + "-" + phone.substring(6);
        }
        return phone;
    }

    public interface onDateTimePickerChangedListener {
        void dateTimeChanged(Calendar date);
    }

    public static void showDatePicker(final Context context, Calendar initialDate, final onDateTimePickerChangedListener listener) {
        new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar date = Calendar.getInstance();
                date.set(year, monthOfYear, dayOfMonth);
                listener.dateTimeChanged(date);
            }
        }, initialDate.get(Calendar.YEAR), initialDate.get(Calendar.MONTH), initialDate.get(Calendar.DATE)).show();
    }

    public static void showTimePicker(final Context context, Calendar initialTime, final onDateTimePickerChangedListener listener) {
        new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                Calendar date = Calendar.getInstance();
                date.set(Calendar.HOUR_OF_DAY, hourOfDay);
                date.set(Calendar.MINUTE, minute);
                listener.dateTimeChanged(date);
            }
        }, initialTime.get(Calendar.HOUR_OF_DAY), initialTime.get(Calendar.MINUTE), false).show();
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    public static void showHide(final Context context, final View view, final Boolean show) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {

            int shortAnimTime = context.getResources().getInteger(android.R.integer.config_shortAnimTime);
            view.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    view.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            view.setVisibility(show ? View.VISIBLE : View.GONE);
        }
    }

    public static void showDiscardChangesDialog(final Activity context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Discard changes?");
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.setPositiveButton("Discard", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                NavUtils.navigateUpFromSameTask(context);
            }
        });
        builder.show();
    }

    public static void showAboutDialog(final Activity context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = context.getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_about, null);
        builder.setView(view)
                .setTitle("About Invictus Lifestyle");
        try {
            ((TextView) view.findViewById(R.id.version)).setText("Version: " + context.getApplication().getPackageManager().getPackageInfo(context.getApplication().getPackageName(), 0).versionName);
        } catch (Exception ex) {
            Log.e(Utilities.TAG, Log.getStackTraceString(ex));
        }
        builder.setPositiveButton("Dismiss", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.create().show();
    }

    public static void hideKeyboard(Activity context) {
        View view = context.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public static void saveException(Throwable exception, Context context) {
        ExceptionHandler.saveException(exception, Thread.currentThread(), createCrashManagerListerner(context));
    }

    public static CrashManagerListener createCrashManagerListerner(final Context context) {
        if (_crashManagerListener == null) {
            _crashManagerListener = new CrashManagerListener() {
                @Override
                public String getUserID() {
                    long userId = PreferenceManager.getDefaultSharedPreferences(context).getLong("userId", 0);
                    return userId > 0 ? String.valueOf(userId) : super.getUserID();
                }

                @Override
                public boolean shouldAutoUploadCrashes() {
                    return true;
                }
            };
        }
        return _crashManagerListener;
    }

    public final static boolean isValidEmail(CharSequence target) {
        return target != null && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public final static boolean checkPlayServices(final BaseActivity activity) {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(activity);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(activity, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                Log.i(Utilities.TAG, "This device is not supported by Google Play Services.");
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(activity, "This device is not supported by Google Play Services.", Toast.LENGTH_LONG).show();
                    }
                });
            }
            return false;
        }
        return true;
    }
}
