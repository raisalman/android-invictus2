package net.invictusmanagement.invictuslifestyle;

import android.content.Intent;
import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceIdService;

public class ChatInstanceIdService extends FirebaseInstanceIdService {

    @Override
    public void onTokenRefresh() {

        Log.d(Utilities.TAG, "Refreshing Firebase Cloud Messaging Registration Token");
        startService(new Intent(this, ChatRegistrationIntentService.class));
    }
}
